import React, { useState } from 'react';
import DiagramViewer from './components/DiagramViewer';
import InputForm from './components/InputForm';
import { INITIAL_PROMPT, CATEGORY_COLORS } from './constants';
import aiService from './services/aiService';
import { FlowState } from './types';
import { Layers, Info, PanelLeftClose, PanelLeftOpen } from 'lucide-react';

const App: React.FC = () => {
  const [state, setState] = useState<FlowState>({
    isLoading: false,
    error: null,
    graphData: null,
  });
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const handleGenerate = async (prompt: string) => {
    setState((prev) => ({ ...prev, isLoading: true, error: null }));
    try {
      const data = await aiService.parseGraphData(prompt);
      setState({ isLoading: false, error: null, graphData: data });
    } catch (err: any) {
      setState((prev) => ({
        ...prev,
        isLoading: false,
        error: err.message || 'An unexpected error occurred.',
      }));
    }
  };

  return (
    <div className="h-screen w-screen bg-slate-950 text-slate-100 flex flex-col overflow-hidden">
      {/* Header - Slimmer */}
      <header className="h-14 border-b border-slate-800 bg-slate-900/80 backdrop-blur-md z-20 flex-shrink-0 flex items-center justify-between px-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shadow-lg shadow-blue-500/20">
            <Layers className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-lg font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400 hidden sm:block">
            FlowGen AI
          </h1>
        </div>
        
        <div className="flex items-center gap-2">
           <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 hover:bg-slate-800 rounded-md transition-colors text-slate-400 hover:text-white"
            title={isSidebarOpen ? "Collapse Sidebar" : "Expand Sidebar"}
           >
            {isSidebarOpen ? <PanelLeftClose className="w-5 h-5" /> : <PanelLeftOpen className="w-5 h-5" />}
           </button>
        </div>
      </header>

      {/* Main Workspace */}
      <main className="flex-1 flex overflow-hidden relative">
        
        {/* Sidebar */}
        <div 
          className={`
            flex-shrink-0 bg-slate-900 border-r border-slate-800 transition-all duration-300 ease-in-out flex flex-col overflow-hidden
            ${isSidebarOpen ? 'w-full sm:w-[400px] translate-x-0' : 'w-0 -translate-x-full opacity-0'}
          `}
        >
          <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-6">
             <InputForm
                initialValue={INITIAL_PROMPT}
                onGenerate={handleGenerate}
                isLoading={state.isLoading}
                error={state.error}
              />

              {/* Legend Component */}
              <div className="p-4 bg-slate-950/50 rounded-xl border border-slate-800/50">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-3">
                  Component Types
                </h3>
                <div className="grid grid-cols-2 gap-2 mb-4">
                  {Object.entries(CATEGORY_COLORS).map(([key, style]) => (
                    <div key={key} className="flex items-center gap-2">
                      <span
                        className="w-3 h-3 rounded-full shadow-sm"
                        style={{ backgroundColor: style.border, boxShadow: `0 0 8px ${style.border}40` }}
                      ></span>
                      <span className="text-xs text-slate-300 capitalize">
                        {key.toLowerCase()}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="pt-4 border-t border-slate-800/50">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-3">
                    Flow Indicators
                  </h3>
                  <div className="flex flex-col gap-3">
                    <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-slate-900 border-2 border-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]"></div>
                        <span className="text-xs text-slate-300">Start Point</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-slate-900 border-2 border-red-500 shadow-[0_0_8px_rgba(239,68,68,0.6)]"></div>
                        <span className="text-xs text-slate-300">End Point</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <div className="w-6 h-0.5 bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.6)]"></div>
                        <span className="text-xs text-slate-300">Data Flow Path</span>
                    </div>
                  </div>
                </div>
              </div>
          </div>
        </div>

        {/* Diagram Area - Takes all remaining space */}
        <div className="flex-1 relative bg-slate-950/50 h-full w-full overflow-hidden">
          {/* subtle grid pattern background */}
          <div className="absolute inset-0 opacity-[0.03] pointer-events-none" 
               style={{ 
                 backgroundImage: 'radial-gradient(#94a3b8 1px, transparent 1px)', 
                 backgroundSize: '24px 24px' 
               }}>
          </div>
          <DiagramViewer data={state.graphData} />
        </div>
      </main>
    </div>
  );
};

export default App;