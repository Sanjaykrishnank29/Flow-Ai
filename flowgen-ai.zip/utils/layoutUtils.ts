import React from 'react';
import dagre from 'dagre';
import { Node, Edge, MarkerType, Position } from 'reactflow';
import { CATEGORY_COLORS } from '../constants';
import { GeneratedGraphData } from '../types';

const nodeWidth = 220;
const nodeHeight = 80;

// Helper to safely get dagre graph instance
const getDagreGraph = () => {
  try {
    let d = dagre;
    // @ts-ignore
    if (d?.default) d = d.default;
    
    if (d?.graphlib?.Graph) {
      return new d.graphlib.Graph();
    }
    console.warn("Dagre graphlib not found in import", d);
  } catch (e) {
    console.warn("Failed to instantiate Dagre graph", e);
  }
  return null;
};

export const getLayoutedElements = (graphData: GeneratedGraphData) => {
  const dagreGraph = getDagreGraph();
  let layoutSuccess = false;

  // Attempt Dagre Layout
  if (dagreGraph && graphData.nodes.length > 0) {
    try {
      dagreGraph.setDefaultEdgeLabel(() => ({}));
      dagreGraph.setGraph({ rankdir: 'TB', nodesep: 60, ranksep: 80 });

      graphData.nodes.forEach((node) => {
        dagreGraph.setNode(node.id, { width: nodeWidth, height: nodeHeight });
      });

      graphData.edges.forEach((edge) => {
        dagreGraph.setEdge(edge.source, edge.target);
      });

      // Apply layout
      let d = dagre;
      // @ts-ignore
      if (d?.default) d = d.default;
      d.layout(dagreGraph);

      // Verify layout actually worked by checking the first node's position
      const firstNode = dagreGraph.node(graphData.nodes[0].id);
      if (firstNode && Number.isFinite(firstNode.x) && Number.isFinite(firstNode.y)) {
        layoutSuccess = true;
      } else {
        console.warn("Dagre layout ran but produced invalid coordinates.");
      }
    } catch (err) {
      console.error("Dagre layout failed:", err);
      layoutSuccess = false;
    }
  }

  // Identify Start and End nodes for styling
  const targetIds = new Set(graphData.edges.map((e) => e.target));
  const sourceIds = new Set(graphData.edges.map((e) => e.source));

  // Convert to React Flow Nodes
  const flowNodes: Node[] = graphData.nodes.map((node, index) => {
    const styles = CATEGORY_COLORS[node.category] || CATEGORY_COLORS.OTHER;
    
    const isUserStart = node.label.toLowerCase().includes('user') || node.label.toLowerCase().includes('query');
    const isStart = !targetIds.has(node.id) || isUserStart;
    const isEnd = !sourceIds.has(node.id);
    const isDecision = node.label.includes('?') || node.label.toLowerCase().includes('if ');

    let position = { x: 0, y: 0 };

    if (layoutSuccess && dagreGraph) {
      const n = dagreGraph.node(node.id);
      // Shifts center to top-left
      position = { 
        x: n.x - nodeWidth / 2, 
        y: n.y - nodeHeight / 2 
      };
    } else {
      // Fallback: Grid Layout
      const COLUMNS = 3;
      const col = index % COLUMNS;
      const row = Math.floor(index / COLUMNS);
      position = { 
        x: col * 350, 
        y: row * 150 
      };
    }

    // Define visual appearance separately from layout style
    const appearance = {
      background: styles.bg,
      borderColor: styles.border,
      color: styles.text,
      borderRadius: isDecision ? '28px' : '12px',
      borderWidth: '2px',
      boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
    };

    if (isStart) {
      appearance.borderColor = '#22c55e';
      appearance.borderWidth = '3px';
      appearance.boxShadow = '0 0 15px rgba(34, 197, 94, 0.2)';
    } else if (isEnd) {
      appearance.borderColor = '#ef4444';
      appearance.borderWidth = '3px';
      appearance.boxShadow = '0 0 15px rgba(239, 68, 68, 0.2)';
    }

    return {
      id: node.id,
      type: 'custom',
      sourcePosition: Position.Bottom,
      targetPosition: Position.Top,
      position,
      data: { 
        label: node.label, 
        icon: node.icon, 
        appearance, // Pass visual config to Custom Node
        isHighlighted: false 
      },
      style: { 
        width: nodeWidth, 
        height: nodeHeight,
        zIndex: 10
      },
    };
  });

  const flowEdges: Edge[] = graphData.edges.map((edge) => {
    let edgeColor = '#64748b'; // Default slate-500
    const labelLower = (edge.label || '').toLowerCase();
    
    if (labelLower.includes('yes') || labelLower.includes('valid') || labelLower.includes('success')) edgeColor = '#22c55e';
    else if (labelLower.includes('no') || labelLower.includes('invalid') || labelLower.includes('error')) edgeColor = '#ef4444';

    return {
      id: edge.id,
      source: edge.source,
      target: edge.target,
      label: edge.label,
      type: 'packet',
      data: { isActive: false },
      animated: false,
      style: { stroke: edgeColor, strokeWidth: 1.5 },
      labelStyle: { 
        fill: '#e2e8f0', 
        fontWeight: 500, 
        fontSize: 10,
      },
      labelBgStyle: { fill: '#0f172a', fillOpacity: 0.9, rx: 4, ry: 4 },
      labelBgPadding: [6, 3],
      labelBgBorderRadius: 4,
      markerEnd: {
        type: MarkerType.ArrowClosed,
        color: edgeColor,
      },
    };
  });

  return { nodes: flowNodes, edges: flowEdges };
};