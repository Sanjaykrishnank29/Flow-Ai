import { NodeCategory } from './types';

export const CATEGORY_COLORS: Record<NodeCategory, { bg: string; border: string; text: string }> = {
  [NodeCategory.UI]: { bg: '#dbeafe', border: '#3b82f6', text: '#1e40af' }, // Blue
  [NodeCategory.API]: { bg: '#f3e8ff', border: '#a855f7', text: '#6b21a8' }, // Purple
  [NodeCategory.PROCESSING]: { bg: '#ffedd5', border: '#f97316', text: '#9a3412' }, // Orange
  [NodeCategory.DATABASE]: { bg: '#dcfce7', border: '#22c55e', text: '#166534' }, // Green
  [NodeCategory.EXTERNAL]: { bg: '#f1f5f9', border: '#64748b', text: '#334155' }, // Slate
  [NodeCategory.OTHER]: { bg: '#ffffff', border: '#94a3b8', text: '#0f172a' }, // White
};

export const INITIAL_PROMPT = `
User Query -> Health Records Retrieval (MCP Server).
Health Records Retrieval -> MCP Client.
MCP Client -> Similarity Search Engine (Processing).
Similarity Search Engine -> Decision: Is Similarity Found?.
If YES -> Summarizing Medical Issue -> Update Medical Records -> Secure Database.
If NO -> Notify Doctor -> Secure Database.
Secure Database -> Response to User.
Response to User -> Decision: Is it Serious?.
If YES -> Consult Doctor -> Secure Database.
If NO -> User Query.
`;
