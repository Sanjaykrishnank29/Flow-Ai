import { GoogleGenAI, Type } from "@google/genai";
import { GeneratedGraphData, NodeCategory } from "../types";

const parseGraphData = async (description: string): Promise<GeneratedGraphData> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key is missing in environment variables.");
  }

  const ai = new GoogleGenAI({ apiKey });

  // Generic fallback icons available in Lucide
  const genericIcons = [
    "User", "Database", "Server", "Cloud", "Laptop", "Smartphone", "Globe",
    "Code", "FileText", "Settings", "Shield", "Brain", "Cpu", "Wifi", "Mail",
    "MessageCircle", "Search", "Layers", "Box", "CreditCard", "ShoppingCart",
    "Activity", "HardDrive", "Key", "Monitor", "Tablet"
  ];

  const systemInstruction = `
    You are an expert software architect and systems designer.
    Your task is to analyze a text description of a system architecture and extract the components (nodes) and data flows (edges).
    
    Rules:
    1. Identify all distinct components.
    2. Categorize each component into one of the following: UI, API, PROCESSING, DATABASE, EXTERNAL, OTHER.
    3. Identify all directional flows between components.
    
    4. ICON SELECTION (CRITICAL):
       - If a specific technology, brand, or tool is mentioned (e.g., Python, Java, AWS, Docker, React, Redis, Postgres, Go, Node.js), set the 'icon' field to its common lowercase slug (e.g., 'python', 'java', 'docker', 'aws', 'postgresql', 'react').
       - If NO specific technology is mentioned (generic concept like 'User', 'Client', 'Firewall'), select the most appropriate icon from this generic list: ${genericIcons.join(", ")}.
       - Do not make up random names for generic icons, only use the provided list or valid tech slugs.

    5. Create simple, unique IDs for nodes (e.g., 'node-1', 'node-2').
    6. Ensure the output is strictly valid JSON matching the requested schema.
  `;

  const prompt = `
    Analyze the following system description and generate a flow diagram structure:
    "${description}"
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            nodes: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  label: { type: Type.STRING, description: "Short, displayable name" },
                  category: { 
                    type: Type.STRING, 
                    enum: [
                      NodeCategory.UI, 
                      NodeCategory.API, 
                      NodeCategory.PROCESSING, 
                      NodeCategory.DATABASE, 
                      NodeCategory.EXTERNAL, 
                      NodeCategory.OTHER
                    ] 
                  },
                  icon: {
                    type: Type.STRING,
                    description: "Lowercase tech slug (e.g. 'python') or Generic Icon name (e.g. 'Database')"
                  },
                  description: { type: Type.STRING, description: "Brief explanation of role" }
                },
                required: ["id", "label", "category", "icon"]
              }
            },
            edges: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  source: { type: Type.STRING, description: "ID of source node" },
                  target: { type: Type.STRING, description: "ID of target node" },
                  label: { type: Type.STRING, description: "Label for the arrow (action or data)" }
                },
                required: ["id", "source", "target"]
              }
            }
          },
          required: ["nodes", "edges"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");

    return JSON.parse(text) as GeneratedGraphData;

  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Failed to generate diagram from description. Please try again.");
  }
};

export default { parseGraphData };