export enum NodeCategory {
  UI = 'UI',
  API = 'API',
  PROCESSING = 'PROCESSING',
  DATABASE = 'DATABASE',
  EXTERNAL = 'EXTERNAL',
  OTHER = 'OTHER'
}

export interface RawNode {
  id: string;
  label: string;
  category: NodeCategory;
  description?: string;
  icon?: string;
}

export interface RawEdge {
  id: string;
  source: string;
  target: string;
  label?: string;
}

export interface GeneratedGraphData {
  nodes: RawNode[];
  edges: RawEdge[];
}

export interface FlowState {
  isLoading: boolean;
  error: string | null;
  graphData: GeneratedGraphData | null;
}