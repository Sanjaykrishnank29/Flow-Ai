import React, { useState } from 'react';
import { Play, Sparkles, AlertCircle, Bug } from 'lucide-react';

interface InputFormProps {
  initialValue: string;
  onGenerate: (prompt: string) => void;
  isLoading: boolean;
  error: string | null;
}

const InputForm: React.FC<InputFormProps> = ({ initialValue, onGenerate, isLoading, error }) => {
  const [input, setInput] = useState(initialValue);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) {
      onGenerate(input);
    }
  };
  
  const handleDebug = () => {
    console.log("Current Input:", input);
    alert("Debug check: See console for input details. Ensure your browser console is open.");
  };

  return (
    <div className="flex flex-col w-full bg-slate-950/50 p-5 rounded-xl border border-slate-800/50 shadow-sm">
      <div className="mb-4 flex justify-between items-start">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-400" />
            System Description
          </h2>
          <p className="text-slate-400 text-xs mt-1.5 leading-relaxed">
            Describe the architecture. Mention specific technologies (e.g., Python, React, AWS) for accurate logos.
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <textarea
          className="w-full h-64 bg-slate-900 text-slate-200 border border-slate-800 rounded-lg p-4 resize-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 outline-none transition-all font-mono text-sm leading-relaxed"
          placeholder="e.g. User -> React Frontend -> Python API -> PostgreSQL Database..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={isLoading}
        />

        {error && (
          <div className="p-3 bg-red-900/20 border border-red-800/30 rounded-lg flex items-start gap-2 text-red-200 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        <div className="flex gap-2">
            <button
              type="submit"
              disabled={isLoading || !input.trim()}
              className={`flex-1 py-3 px-4 rounded-lg font-semibold flex items-center justify-center gap-2 transition-all transform active:scale-[0.98] ${
                isLoading || !input.trim()
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                  : 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-900/20'
              }`}
            >
              {isLoading ? (
                <>
                  <svg className="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  <span className="text-sm">Generating...</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-current" />
                  <span className="text-sm">Generate Flow</span>
                </>
              )}
            </button>
            
            {/* Hidden debug button for verify testing */}
             <button
              type="button"
              onClick={handleDebug}
              className="px-3 rounded-lg bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-500 hover:text-slate-300 transition-colors"
              title="Debug Info"
            >
              <Bug className="w-4 h-4" />
            </button>
        </div>
      </form>
    </div>
  );
};

export default InputForm;