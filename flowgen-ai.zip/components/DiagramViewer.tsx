import React, { useEffect, useMemo, useState, useCallback, useRef } from 'react';
import ReactFlow, {
  Background,
  Controls,
  useNodesState,
  useEdgesState,
  ConnectionMode,
  EdgeTypes,
  NodeTypes,
  Node,
  Edge
} from 'reactflow';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  SkipBack, 
  SkipForward, 
  Gauge 
} from 'lucide-react';
import { GeneratedGraphData } from '../types';
import { getLayoutedElements } from '../utils/layoutUtils';
import { PacketEdge } from './PacketEdge';
import IconNode from './IconNode';

interface DiagramViewerProps {
  data: GeneratedGraphData | null;
}

interface SimulationStep {
  nodes: string[];
  edges: string[];
  duration: number; // ms
}

const edgeTypes: EdgeTypes = {
  packet: PacketEdge,
};

const calculateSteps = (nodes: Node[], edges: Edge[]): SimulationStep[] => {
  const steps: SimulationStep[] = [];
  
  // Find start nodes
  const targetIds = new Set(edges.map(e => e.target));
  let startNodes = nodes.filter(n => !targetIds.has(n.id));
  
  if (startNodes.length === 0 && nodes.length > 0) {
    // Fallback if loop or no clear start
    const userNode = nodes.find(n => 
      n.data.label.toLowerCase().includes('user') || 
      n.data.label.toLowerCase().includes('query')
    );
    startNodes = userNode ? [userNode] : [nodes[0]];
  }

  let queue = startNodes.map(n => n.id);
  const visitedEdges = new Set<string>();

  // Add initial empty step to ensure clean start
  steps.push({ nodes: [], edges: [], duration: 500 });

  while (queue.length > 0) {
    const currentBatchIds = [...queue];
    queue = [];

    // Step A: Highlight Nodes
    steps.push({
      nodes: currentBatchIds,
      edges: [],
      duration: 1000
    });

    // Find outgoing edges
    const outgoingEdges = edges.filter(e => currentBatchIds.includes(e.source));
    const activeEdgeIds: string[] = [];

    outgoingEdges.forEach(e => {
      if (!visitedEdges.has(e.id)) {
        visitedEdges.add(e.id);
        activeEdgeIds.push(e.id);
        
        // Add target to next queue if not already processed in this specific path
        // (Simplified BFS)
        if (!currentBatchIds.includes(e.target)) {
           queue.push(e.target);
        }
      }
    });

    // Step B: Highlight Nodes + Activate Edges (if any)
    if (activeEdgeIds.length > 0) {
      steps.push({
        nodes: currentBatchIds,
        edges: activeEdgeIds,
        duration: 1200 
      });
    }
  }

  // Final Step: clear all
  steps.push({ nodes: [], edges: [], duration: 0 });

  return steps;
};

const DiagramViewer: React.FC<DiagramViewerProps> = ({ data }) => {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  
  // Simulation State
  const [steps, setSteps] = useState<SimulationStep[]>([]);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [speed, setSpeed] = useState(1); // 0.5x to 3x

  const nodeTypes: NodeTypes = useMemo(() => ({
    custom: IconNode,
  }), []);

  // Initialize Graph & Calculate Steps
  useEffect(() => {
    if (data) {
      const { nodes: layoutedNodes, edges: layoutedEdges } = getLayoutedElements(data);
      setNodes(layoutedNodes);
      setEdges(layoutedEdges);
      
      const generatedSteps = calculateSteps(layoutedNodes, layoutedEdges);
      setSteps(generatedSteps);
      setCurrentStepIndex(0);
      setIsPlaying(false);
    }
  }, [data, setNodes, setEdges]);

  // Apply Current Step Visuals
  useEffect(() => {
    if (steps.length === 0) return;
    
    // Ensure index is valid
    const index = Math.min(Math.max(currentStepIndex, 0), steps.length - 1);
    const step = steps[index];

    setNodes((nds) => nds.map(n => {
      const isHighlighted = step.nodes.includes(n.id);
      return {
        ...n,
        style: {
          ...n.style,
          zIndex: isHighlighted ? 20 : 10,
        },
        data: {
          ...n.data,
          isHighlighted
        }
      };
    }));

    setEdges((eds) => eds.map(e => {
      const isActive = step.edges.includes(e.id);
      return {
        ...e,
        zIndex: isActive ? 20 : 0,
        data: {
          ...e.data,
          isActive,
          speed
        }
      };
    }));

  }, [currentStepIndex, steps, speed, setNodes, setEdges]);

  // Timer Loop for Playback
  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;

    if (isPlaying && steps.length > 0) {
      const isLastStep = currentStepIndex >= steps.length - 1;
      
      if (isLastStep) {
        setIsPlaying(false);
      } else {
        const currentStepData = steps[currentStepIndex];
        const duration = currentStepData.duration / speed;

        timer = setTimeout(() => {
          setCurrentStepIndex(prev => prev + 1);
        }, duration);
      }
    }

    return () => clearTimeout(timer);
  }, [isPlaying, currentStepIndex, steps, speed]);

  const fitViewOptions = useMemo(() => ({ padding: 0.2 }), []);

  // Controls Handlers
  const togglePlay = () => {
    if (currentStepIndex >= steps.length - 1) {
      setCurrentStepIndex(0);
    }
    setIsPlaying(!isPlaying);
  };

  const handleNext = () => {
    setIsPlaying(false);
    setCurrentStepIndex(prev => Math.min(prev + 1, steps.length - 1));
  };

  const handlePrev = () => {
    setIsPlaying(false);
    setCurrentStepIndex(prev => Math.max(prev - 1, 0));
  };

  const handleReset = () => {
    setIsPlaying(false);
    setCurrentStepIndex(0);
  };

  if (!data) {
    return (
      <div className="w-full h-full flex flex-col items-center justify-center text-slate-500">
        <div className="mb-4 p-4 rounded-full bg-slate-900 border border-slate-800">
          <RotateCcw className="w-8 h-8 opacity-50" />
        </div>
        <p className="text-lg font-medium">Ready to Visualize</p>
        <p className="text-sm opacity-60 mt-2 max-w-xs text-center">
          Enter your system description in the sidebar to generate a flow diagram.
        </p>
      </div>
    );
  }

  return (
    <div className="w-full h-full relative group">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        edgeTypes={edgeTypes}
        nodeTypes={nodeTypes}
        connectionMode={ConnectionMode.Loose}
        fitView
        fitViewOptions={fitViewOptions}
        minZoom={0.1}
        maxZoom={4}
      >
        <Background color="#1e293b" gap={24} size={1} />
        <Controls 
          className="bg-slate-800 border-slate-700 fill-slate-200 text-slate-200"
          showInteractive={false} 
        />
      </ReactFlow>

      {/* Playback Controls Bar */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-20">
        <div className="flex flex-col items-center gap-2">
          
          {/* Main Controls */}
          <div className="flex items-center gap-2 p-2 bg-slate-900/90 backdrop-blur-md border border-slate-700/50 rounded-2xl shadow-2xl">
            
            <button
              onClick={handleReset}
              className="p-2 hover:bg-slate-800 rounded-xl text-slate-400 hover:text-white transition-colors"
              title="Reset"
            >
              <RotateCcw className="w-5 h-5" />
            </button>

            <div className="w-px h-6 bg-slate-700/50 mx-1" />

            <button
              onClick={handlePrev}
              disabled={currentStepIndex === 0}
              className="p-2 hover:bg-slate-800 rounded-xl text-slate-200 disabled:opacity-30 disabled:hover:bg-transparent transition-colors"
              title="Previous Step"
            >
              <SkipBack className="w-5 h-5 fill-current" />
            </button>

            <button
              onClick={togglePlay}
              className={`p-3 rounded-xl transition-all shadow-lg flex items-center justify-center ${
                isPlaying 
                  ? 'bg-amber-500/10 text-amber-500 hover:bg-amber-500/20' 
                  : 'bg-blue-600 text-white hover:bg-blue-500 hover:scale-105 active:scale-95'
              }`}
              title={isPlaying ? "Pause" : "Play"}
            >
              {isPlaying ? <Pause className="w-6 h-6 fill-current" /> : <Play className="w-6 h-6 fill-current ml-0.5" />}
            </button>

            <button
              onClick={handleNext}
              disabled={currentStepIndex >= steps.length - 1}
              className="p-2 hover:bg-slate-800 rounded-xl text-slate-200 disabled:opacity-30 disabled:hover:bg-transparent transition-colors"
              title="Next Step"
            >
              <SkipForward className="w-5 h-5 fill-current" />
            </button>

            <div className="w-px h-6 bg-slate-700/50 mx-1" />

            {/* Speed Control */}
            <div className="flex items-center gap-2 px-2 group/speed relative">
               <Gauge className="w-4 h-4 text-slate-400" />
               <div className="w-24">
                 <input 
                    type="range" 
                    min="0.5" 
                    max="3" 
                    step="0.5" 
                    value={speed}
                    onChange={(e) => setSpeed(parseFloat(e.target.value))}
                    className="w-full h-1 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
                 />
               </div>
               <span className="text-xs font-mono text-slate-400 w-8 text-right">{speed}x</span>
            </div>

          </div>

          {/* Progress Indicator */}
          <div className="text-xs font-medium text-slate-400 bg-slate-900/50 px-3 py-1 rounded-full backdrop-blur-sm border border-slate-800">
            Step {currentStepIndex} / {Math.max(0, steps.length - 1)}
          </div>
          
        </div>
      </div>
    </div>
  );
};

export default DiagramViewer;