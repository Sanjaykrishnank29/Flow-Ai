import React, { memo, useState, useEffect } from 'react';
import { Handle, Position, NodeProps } from 'reactflow';
import {
  User, Database, Server, Cloud, Laptop, Smartphone, Globe, Code,
  FileText, Settings, Shield, Brain, Cpu, Wifi, Mail, MessageCircle,
  Search, Layers, Box, CreditCard, ShoppingCart, Activity, HardDrive,
  Key, Monitor, Tablet
} from 'lucide-react';

const iconMap: Record<string, React.FC<any>> = {
  User, Database, Server, Cloud, Laptop, Smartphone, Globe, Code,
  FileText, Settings, Shield, Brain, Cpu, Wifi, Mail, MessageCircle,
  Search, Layers, Box, CreditCard, ShoppingCart, Activity, HardDrive,
  Key, Monitor, Tablet
};

const IconNode = ({ data }: NodeProps) => {
  const [imgError, setImgError] = useState(false);
  const iconKey = data.icon || 'Box';
  const GenericIcon = iconMap[iconKey];
  
  const { appearance, isHighlighted } = data;

  useEffect(() => {
    setImgError(false);
  }, [iconKey]);

  const renderIcon = () => {
    if (GenericIcon) {
      return <GenericIcon className="w-7 h-7 mb-1.5 opacity-90 text-current" strokeWidth={1.5} />;
    }
    if (iconKey && !imgError) {
      return (
        <img 
          src={`https://cdn.simpleicons.org/${iconKey.toLowerCase()}`}
          alt={data.label}
          className="w-7 h-7 mb-1.5 object-contain"
          onError={() => setImgError(true)}
        />
      );
    }
    return <Box className="w-7 h-7 mb-1.5 opacity-90 text-current" strokeWidth={1.5} />;
  };

  const containerStyle: React.CSSProperties = {
    background: appearance?.background || '#ffffff',
    borderColor: isHighlighted ? '#3b82f6' : (appearance?.borderColor || '#94a3b8'),
    color: appearance?.color || '#0f172a',
    borderRadius: appearance?.borderRadius || '12px',
    borderWidth: appearance?.borderWidth || '2px',
    borderStyle: 'solid',
    boxShadow: isHighlighted ? '0 0 25px 8px rgba(59, 130, 246, 0.6)' : (appearance?.boxShadow || 'none'),
    width: '100%',
    height: '100%',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
    transform: isHighlighted ? 'scale(1.08)' : 'scale(1)',
  };

  return (
    <div style={containerStyle}>
      <Handle 
        type="target" 
        position={Position.Top} 
        className="!bg-slate-400/50 !w-2 !h-1 !rounded-b-sm !border-none" 
        style={{ top: 0 }}
      />
      
      {renderIcon()}
      
      <span className="text-[11px] font-semibold text-center leading-3 line-clamp-2 w-full break-words px-2">
        {data.label || 'Unknown Node'}
      </span>
      
      <Handle 
        type="source" 
        position={Position.Bottom} 
        className="!bg-slate-400/50 !w-2 !h-1 !rounded-t-sm !border-none"
        style={{ bottom: 0 }}
      />
    </div>
  );
};

export default memo(IconNode);