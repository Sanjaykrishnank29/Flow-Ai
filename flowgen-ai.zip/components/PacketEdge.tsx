import React from 'react';
import { BaseEdge, EdgeProps, getBezierPath } from 'reactflow';

export const PacketEdge: React.FC<EdgeProps> = ({
  id,
  sourceX,
  sourceY,
  targetX,
  targetY,
  sourcePosition,
  targetPosition,
  style = {},
  markerEnd,
  data,
}) => {
  // Use Bezier Path for smooth curves (best for TB layout)
  const [edgePath] = getBezierPath({
    sourceX,
    sourceY,
    sourcePosition,
    targetX,
    targetY,
    targetPosition,
  });

  const isActive = data?.isActive;
  // Calculate duration based on speed. Base duration is 1.2s
  // If speed is 2x, duration is 0.6s.
  const speed = data?.speed || 1;
  const duration = `${1.2 / speed}s`;

  return (
    <>
      <BaseEdge 
        path={edgePath} 
        markerEnd={markerEnd} 
        style={{ 
          ...style, 
          strokeOpacity: isActive ? 1 : 0.3, 
          stroke: isActive ? '#3b82f6' : '#64748b', // Blue when active
          strokeWidth: isActive ? 2.5 : 1.5,
          transition: 'all 0.5s ease'
        }} 
      />
      {isActive && (
        <g>
          {/* Glowing Blue Circle Particle */}
          <circle r="6" fill="#60a5fa" filter="drop-shadow(0 0 8px rgba(59, 130, 246, 0.8))">
            <animateMotion 
              dur={duration}
              repeatCount="1"
              fill="freeze"
              path={edgePath}
              calcMode="spline"
              keyTimes="0;1"
              keySplines="0.4 0 0.2 1" 
            />
          </circle>
        </g>
      )}
    </>
  );
};